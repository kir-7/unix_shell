tar -cvf file.tar *.sh

echo ""
tar -xvf file.tar
echo ""
tar -tvf file.tar
echo ""
tar -zcvf file2.tar.gzip *.txt
echo ""
tar -xzvf file2.tar.gzip
echo ""
tar -uvf file.tar trail.txt
echo ""
tar -cvf file4.tar stu_month.txt
echo ""
tar -xvf file3.tar
echo ""